// ========================================================================
// app.js — 메일링 에이전트 AI 메인 애플리케이션
// ========================================================================
//
// 책임:
//   - UI 렌더링 (메시지, TAO 패널)
//   - TAO (Thought-Action-Observation) 로깅
//   - 에이전트 추론 엔진 (agentReason)
//   - 가드레일 통합 (guardrails.js 호출)
//   - 도구 호출 (tools.js 함수 호출)
//   - 비상 정지 버튼
//
// 로드 순서: guardrails.js → tools.js → app.js
// ========================================================================

// ===== DOM Elements =====
const chatMessages = document.getElementById('chatMessages');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');
const clearBtn = document.getElementById('clearBtn');
const stopBtn = document.getElementById('stopBtn');
const taoToggle = document.getElementById('taoToggle');
const taoBody = document.getElementById('taoBody');
const taoLogList = document.getElementById('taoLogList');
const taoEmpty = document.getElementById('taoEmpty');
const taoCount = document.getElementById('taoCount');
const taoArrow = document.getElementById('taoArrow');

// ===== Agent State =====
const agentState = {
    userRequest: '',
    recipient: '',
    subject: '',
    keyContent: '',
    missingInfo: [],
    emailDraft: null,
    sendResult: null,
    taoLog: [],
    phase: 'idle',            // idle | collecting | composing | confirming | done
    waitingForInput: false,
    pendingSendApproval: false,
    stopRequested: false       // 비상 정지 플래그
};

// ===== TAO Counter =====
let taoSequenceNumber = 0;

// ========================================================================
// UI 참조 객체 (tools.js에 주입)
// ========================================================================

const UI = {
    escapeHtml: function(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    addAgentMessage: function(html) {
        if (agentState.stopRequested) return;
        const div = document.createElement('div');
        div.className = 'message agent-message';
        div.innerHTML = `
            <div class="message-icon"><i class="fas fa-envelope"></i></div>
            <div class="message-body">
                <div class="message-content">${html}</div>
                <span class="message-time">${getCurrentTime()}</span>
            </div>
        `;
        chatMessages.appendChild(div);
        scrollToBottom();
    },
    addSystemMessage: function(text) {
        if (agentState.stopRequested) return;
        const div = document.createElement('div');
        div.className = 'message system-message';
        div.innerHTML = `
            <div class="message-body">
                <div class="message-content"><p>${UI.escapeHtml(text)}</p></div>
                <span class="message-time">${getCurrentTime()}</span>
            </div>
        `;
        chatMessages.appendChild(div);
        scrollToBottom();
    }
};

// tools.js에 UI 참조 주입
setToolUI(UI);

// ========================================================================
// TAO 로그 함수 (tools.js에 주입)
// ========================================================================

function addTaoLog(action, thought, observation) {
    if (agentState.stopRequested) return;

    taoSequenceNumber++;
    const entry = {
        sequence: taoSequenceNumber,
        tool: action,
        thought: thought,
        action: action,
        observation: observation,
        timestamp: new Date().toISOString()
    };
    agentState.taoLog.push(entry);

    // TAO 패널 업데이트
    taoEmpty.style.display = 'none';
    taoCount.textContent = taoSequenceNumber;

    const toolClass = getToolClass(action);
    const toolLabel = getToolLabel(action);

    const item = document.createElement('div');
    item.className = 'tao-log-item';
    item.innerHTML = `
        <div class="tao-log-header">
            <span class="tao-log-number">#${taoSequenceNumber}</span>
            <span class="tao-log-tool ${toolClass}">${toolLabel}</span>
        </div>
        <div class="tao-log-detail">
            <div><span class="tao-label">T:</span> ${UI.escapeHtml(thought)}</div>
            <div><span class="tao-label">A:</span> ${toolLabel}</div>
            <div><span class="tao-label">O:</span> ${UI.escapeHtml(observation)}</div>
        </div>
    `;
    taoLogList.appendChild(item);

    // 자동 열림
    if (!taoBody.classList.contains('open')) {
        taoBody.classList.add('open');
        taoArrow.style.transform = 'rotate(180deg)';
    }
}

// tools.js에 TAO 참조 주입
setTaoRef(addTaoLog);

// ========================================================================
// 도구 라벨/클래스 헬퍼
// ========================================================================

function getToolLabel(tool) {
    switch (tool) {
        case 'askUser': return '💬 askUser';
        case 'composeMail': return '🟢 composeMail';
        case 'showPreview': return '🟢 showPreview';
        case 'sendMail': return '🔴 sendMail';
        case '🛑 중지': return '🛑 중지';
        default: return tool;
    }
}

function getToolClass(tool) {
    switch (tool) {
        case 'askUser': return 'ask';
        case 'composeMail':
        case 'showPreview': return 'compose';
        case 'sendMail': return 'send';
        default: return 'system';
    }
}

// ========================================================================
// 유틸리티 함수
// ========================================================================

function getCurrentTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}

function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// ========================================================================
// 메시지 렌더링
// ========================================================================

function addUserMessage(text) {
    const div = document.createElement('div');
    div.className = 'message user-message';
    div.innerHTML = `
        <div class="message-body">
            <div class="message-content"><p>${UI.escapeHtml(text)}</p></div>
            <span class="message-time">${getCurrentTime()}</span>
        </div>
    `;
    chatMessages.appendChild(div);
    scrollToBottom();
}

// ========================================================================
// 요청 분석 함수
// ========================================================================

function analyzeRequest(text) {
    const result = {
        recipient: '',
        subject: '',
        content: ''
    };

    // 받는 사람 추출: "XXX님에게" or "XXX에게" or "XXX한테"
    const recipientMatch = text.match(/([^\s]+(?:님|에게|한테|께))/);
    if (recipientMatch) {
        result.recipient = recipientMatch[1].replace(/(에게|한테|께)$/, '').trim();
    }

    // 제목/주제 추출
    const subjectMatch = text.match(/(?:메일|이메일)\s*(?:보내|작성|써)/);
    if (subjectMatch) {
        const beforeMail = text.split(/(?:메일|이메일)/)[0];
        let subj = beforeMail.replace(/(?:에게|한테|께|님)\s*$/, '').trim();
        subj = subj.replace(/(?:보내|작성|써|줘|주세요|해줘)\s*$/, '').trim();
        subj = subj.replace(/(?:에게|한테|께)\s*$/, '').trim();
        if (result.recipient) {
            subj = subj.replace(result.recipient, '').trim();
        }
        if (subj) {
            result.subject = subj;
        }
    }

    if (!result.subject) {
        const contentMatch = text.match(/(.+?)(?:내용|관련|건으로|에 대해)/);
        if (contentMatch) {
            let subj = contentMatch[1].replace(/(?:에게|한테|께|님)\s*$/, '').trim();
            if (result.recipient) {
                subj = subj.replace(result.recipient, '').trim();
            }
            if (subj) {
                result.subject = subj;
            }
        }
    }

    if (!result.subject) {
        result.subject = '메일 드립니다';
    }

    // 본문 내용 추출
    const contentKeywords = [
        '내용은', '내용:', '내용', '본문은', '본문:',
        '다음과 같이', '아래와 같이', '말씀드리면'
    ];
    for (const kw of contentKeywords) {
        if (text.includes(kw)) {
            const idx = text.indexOf(kw) + kw.length;
            const content = text.substring(idx).trim();
            if (content) {
                result.content = content;
                break;
            }
        }
    }

    if (!result.content) {
        result.content = result.subject;
    }

    return result;
}

// ========================================================================
// 에이전트 추론 엔진 (TAO 방식)
// ========================================================================

function agentReason(userMessage) {
    // 1. 비상 정지 확인
    if (agentState.stopRequested) {
        UI.addSystemMessage('⏸️ 모든 작업이 중지되었습니다. 새로운 요청을 입력해주세요.');
        agentState.stopRequested = false;
        agentState.phase = 'idle';
        return;
    }

    // 2. 입력 가드레일 검사
    const guardResult = validateInput(userMessage);
    if (!guardResult.safe) {
        // 거부: ①거부사실 ②사유 ③건전한 대안
        addTaoLog('system', `입력 검증: ${guardResult.category} 감지`, `거부: ${guardResult.reason}`);
        UI.addAgentMessage(`
            <span class="tool-badge system">🚫 요청 거부</span>
            <p><strong>① 죄송합니다, 해당 요청은 수행할 수 없습니다.</strong></p>
            <p>② 이유: ${UI.escapeHtml(guardResult.reason)}</p>
            <p>③ ${UI.escapeHtml(guardResult.alternative)}</p>
        `);
        return;
    }

    // 개인정보 경고
    if (guardResult.piiWarning) {
        UI.addAgentMessage(`
            <span class="tool-badge system">⚠️ 주의</span>
            <p>${UI.escapeHtml(guardResult.reason)}</p>
        `);
    }

    // 3. Phase 기반 처리
    if (agentState.phase === 'idle' || agentState.phase === 'done') {
        handleNewRequest(userMessage);
        return;
    }

    if (agentState.waitingForInput) {
        handleUserResponse(userMessage);
        return;
    }

    if (agentState.pendingSendApproval) {
        UI.addAgentMessage(`<p>위에 표시된 메일 미리보기를 확인해주세요.</p><p style="font-size:13px;color:#6b7280;">"확인" 또는 "취소" 버튼을 클릭해주세요.</p>`);
        return;
    }

    // 기본 응답
    UI.addAgentMessage(`
        <p>메일 작성 요청을 해주세요! 📧</p>
        <p style="margin-top:4px;font-size:13px;color:#6b7280;">
            예: "<em>sunny.icmhs@gmail.com에게 프로젝트 회의 결과 메일 보내줘</em>"
        </p>
    `);
}

// ===== 새 요청 처리 =====
function handleNewRequest(userMessage) {
    agentState.userRequest = userMessage;
    agentState.recipient = '';
    agentState.subject = '';
    agentState.keyContent = '';
    agentState.missingInfo = [];
    agentState.emailDraft = null;
    agentState.sendResult = null;
    agentState.phase = 'collecting';

    // 요청 분석
    const analysis = analyzeRequest(userMessage);
    if (analysis.recipient) agentState.recipient = analysis.recipient;
    if (analysis.subject) agentState.subject = analysis.subject;
    if (analysis.content) agentState.keyContent = analysis.content;

    // 부족한 정보 확인
    const missing = [];
    if (!agentState.recipient) missing.push('받는 사람 (이메일 주소)');
    if (!agentState.subject) missing.push('메일 제목');
    if (!agentState.keyContent) missing.push('본문 내용');

    if (missing.length > 0) {
        agentState.missingInfo = missing;
        const question = `메일 작성을 위해 다음 정보가 필요합니다:\n• ${missing.join('\n• ')}\n\n하나씩 알려주세요!`;

        // TAO: Thought → Action (askUser 대체)
        addTaoLog('askUser', `요청 분석 결과 부족한 정보 감지: ${missing.join(', ')}`, '사용자 응답 대기 중...');
        agentState.waitingForInput = true;
        UI.addAgentMessage(`
            <span class="tool-badge ask">💬 askUser</span>
            <p><strong>📋 추가 정보가 필요합니다.</strong></p>
            <p>${UI.escapeHtml(question)}</p>
            <p style="margin-top:6px;font-size:12px;color:#6b7280;">✏️ 위에 답변을 입력해주세요.</p>
        `);
        userInput.focus();
        return;
    }

    // 모든 정보 있음 → composeMail → showPreview
    proceedToCompose();
}

// ===== 사용자 응답 처리 =====
function handleUserResponse(answer) {
    agentState.waitingForInput = false;

    // 응답을 상태에 반영
    if (!agentState.recipient) {
        agentState.recipient = answer;
    } else if (!agentState.subject) {
        agentState.subject = answer;
    } else if (!agentState.keyContent) {
        agentState.keyContent = answer;
    } else {
        agentState.keyContent += '\n' + answer;
    }

    // 아직 부족한 정보 확인
    const missing = [];
    if (!agentState.recipient) missing.push('받는 사람 (이메일 주소)');
    if (!agentState.subject) missing.push('메일 제목');
    if (!agentState.keyContent) missing.push('본문 내용');

    if (missing.length > 0) {
        agentState.missingInfo = missing;
        const question = `아직 다음 정보가 필요합니다:\n• ${missing.join('\n• ')}\n\n알려주세요!`;

        addTaoLog('askUser', `추가 정보 필요: ${missing.join(', ')}`, '사용자 응답 대기 중...');
        agentState.waitingForInput = true;
        UI.addAgentMessage(`
            <span class="tool-badge ask">💬 askUser</span>
            <p><strong>📋 추가 정보가 필요합니다.</strong></p>
            <p>${UI.escapeHtml(question)}</p>
            <p style="margin-top:6px;font-size:12px;color:#6b7280;">✏️ 위에 답변을 입력해주세요.</p>
        `);
        userInput.focus();
        return;
    }

    // 모든 정보 수집 완료 → composeMail → showPreview
    proceedToCompose();
}

// ===== composeMail + showPreview 연속 실행 =====
function proceedToCompose() {
    if (agentState.stopRequested) return;

    // 1. 수신인 이메일 형식 확인 (입력이 이름만 있을 경우)
    let recipient = agentState.recipient;
    if (recipient && !recipient.includes('@')) {
        // 친구 목록에서 이름으로 찾기 (친구 이름 매핑)
        const nameMap = {
            'sunny': 'sunny.icmhs@gmail.com',
            '선니': 'sunny.icmhs@gmail.com',
            '선미': 'sunny.icmhs@gmail.com',
            '김민지': '2026gs20914@gosaek.hs.kr',
            '민지': '2026gs20914@gosaek.hs.kr',
            '이지현': '2026gs20511@gosaek.hs.kr',
            '지현': '2026gs20511@gosaek.hs.kr'
        };
        const mapped = nameMap[recipient.toLowerCase()];
        if (mapped) {
            recipient = mapped;
            agentState.recipient = mapped;
        }
    }

    // 2. composeMail 실행
    const result = composeMail(recipient, agentState.subject, agentState.keyContent);
    if (!result.success) {
        agentState.phase = 'idle';
        return;
    }

    // 3. showPreview 실행 (자동)
    agentState.emailDraft = result.draft;
    agentState.phase = 'confirming';
    agentState.pendingSendApproval = true;

    showPreview(result.draft);
}

// ========================================================================
// 대화 초기화
// ========================================================================

function resetConversation() {
    agentState.userRequest = '';
    agentState.recipient = '';
    agentState.subject = '';
    agentState.keyContent = '';
    agentState.missingInfo = [];
    agentState.emailDraft = null;
    agentState.sendResult = null;
    agentState.phase = 'idle';
    agentState.waitingForInput = false;
    agentState.pendingSendApproval = false;
    agentState.stopRequested = false;
    agentState.taoLog = [];
    taoSequenceNumber = 0;

    chatMessages.innerHTML = `
        <div class="message agent-message">
            <div class="message-icon"><i class="fas fa-envelope"></i></div>
            <div class="message-body">
                <div class="message-content">
                    <p>안녕하세요! 📧 <strong>메일링 에이전트 AI</strong>입니다.</p>
                    <p>메일 작성이 필요하시면 언제든지 말씀해주세요.</p>
                    <p style="margin-top:8px;font-size:13px;color:#6b7280;">
                        예: "<em>sunny.icmhs@gmail.com에게 프로젝트 일정 회의 메일 보내줘</em>"
                    </p>
                </div>
                <span class="message-time">방금 전</span>
            </div>
        </div>
    `;

    taoLogList.innerHTML = '';
    taoEmpty.style.display = 'block';
    taoCount.textContent = '0';

    // 게이트 초기화 (tools.js)
    resetGate();
}

// ========================================================================
// 비상 정지
// ========================================================================

function emergencyStop() {
    agentState.stopRequested = true;
    agentState.phase = 'idle';
    agentState.waitingForInput = false;

    addTaoLog('🛑 중지', '사용자가 비상 정지 버튼을 클릭', '모든 추론과 행동을 중단합니다.');
    UI.addSystemMessage('🛑 비상 정지! 모든 작업이 중단되었습니다.');
    UI.addAgentMessage(`<p>⏸️ 모든 작업이 중지되었습니다. 새로운 요청을 입력해주세요.</p>`);

    userInput.disabled = false;
    userInput.focus();
    stopBtn.style.display = 'none';
}

// ========================================================================
// 메인 전송 핸들러
// ========================================================================

function handleSend() {
    const text = userInput.value.trim();
    if (!text) return;

    userInput.value = '';
    userInput.style.height = 'auto';

    // 중지 상태 해제
    if (agentState.stopRequested) {
        agentState.stopRequested = false;
        stopBtn.style.display = 'flex';
    }

    addUserMessage(text);

    // TAO: Thought 기록 (추론 시작)
    addTaoLog('system', `사용자 메시지 수신: "${text}"`, '가드레일 검사 및 추론 시작');

    agentReason(text);
}

// ========================================================================
// 이벤트 리스너
// ========================================================================

sendBtn.addEventListener('click', handleSend);

userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
    }
});

userInput.addEventListener('input', () => {
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 100) + 'px';
});

clearBtn.addEventListener('click', () => {
    if (confirm('대화를 초기화하시겠습니까?')) {
        resetConversation();
    }
});

stopBtn.addEventListener('click', emergencyStop);

// TAO 패널 토글
taoToggle.addEventListener('click', () => {
    taoBody.classList.toggle('open');
    if (taoBody.classList.contains('open')) {
        taoArrow.style.transform = 'rotate(180deg)';
    } else {
        taoArrow.style.transform = 'rotate(0deg)';
    }
});

// ========================================================================
// 초기화
// ========================================================================

userInput.focus();