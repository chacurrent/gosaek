// ========================================================================
// guardrails.js — 메일링 에이전트 AI 안전 가드레일 모듈
// ========================================================================
//
// 코드로 강제하는 안전 규칙 (SAFETY_POLICY.md와 동기화):
//   1. 허용 외 도구 차단         → validateTool()
//   2. 허용 외 수신자 차단       → validateRecipient()
//   3. sendMail 전 showPreview   → 게이트 검사 (tools.js에서 호출)
//   4. 동일 도구 5회 제한        → retryTracker
//   5. 비상 정지 버튼           → app.js stopRequested
//   6. 실패 시 결과 지어내지 않음 → tools.js 직접 반환
//   7. 4가지 유형 요청 거부       → validateInput()
// ========================================================================

// ===== 친구 메일 주소 화이트리스트 =====
const FRIEND_EMAILS = [
    'sunny.icmhs@gmail.com',
    '2026gs20914@gosaek.hs.kr',
    '2026gs20511@gosaek.hs.kr'
];

// ===== 허용 도구 목록 =====
const ALLOWED_TOOLS = ['composeMail', 'showPreview', 'sendMail'];

// ===== 재시도 추적기 =====
const MAX_RETRY = 5;
const retryTracker = {};

// ===== 개인정보 패턴 (정규식) =====
const PII_PATTERNS = [
    { pattern: /\b\d{6}[-\s]?\d{7}\b/g, label: '주민등록번호' },
    { pattern: /\b(010|011|016|017|018|019)[-\s]?\d{3,4}[-\s]?\d{4}\b/g, label: '휴대폰번호' },
    { pattern: /\b\d{2,3}[-\s]?\d{3,4}[-\s]?\d{4}\b/g, label: '전화번호' },
    { pattern: /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/g, label: '카드번호' }
];

// ===== 유해 콘텐츠 키워드 =====
const HATE_KEYWORDS = [
    '죽여', '죽일', '죽겠', '시체', '자살',
    '폭력', '강간', '성폭행', '성추행',
    '쓰레기', '한심한', '정신병자'
];

// ===== 욕설·비방 키워드 =====
const ABUSE_KEYWORDS = [
    '시발', '씨발', '개새끼', '병신',
    '니애미', '느금마', '등신', '찐따',
    '븅신', 'ㅅㅂ', 'ㅄ', 'ㄷㅊ'
];

// ===== 탈옥·우회 패턴 =====
const JAILBREAK_PATTERNS = [
    /이전\s+(규칙|지침)\s+(모두\s+)?무시/i,
    /ignore\s+(all\s+)?(previous|above)\s+(rules|instructions)/i,
    /(보안|안전)\s*(규칙|제한)\s*해제/i,
    /jailbreak\s*(prompt|injection)/i,
    /do\s+anything\s+now/i
];

// ===== 차별·혐오 패턴 =====
const DISCRIMINATION_PATTERNS = [
    /(여자는?|여자들이?)\s+(안\s+되는|못\s+하는)\s+(것|거|일)/i,
    /(남자는?|남자들이?)\s+(안\s+되는|못\s+하는)\s+(것|거|일)/i,
    /(외국인|이민자|난민)\s+때문에/i,
    /지역\s*(비하|감정)\s*(하는|할)/i
];

// ===== 거짓·기만 패턴 =====
const DECEPTION_PATTERNS = [
    /(사칭|허위|거짓|가짜)\s+(메일|이메일|편지|내용|사유)/i,
    /(교장|선생님|담임)\s*(인\s*척|처럼)\s*(메일|편지|이메일)/i,
    /(부모님|아빠|엄마)\s*(인\s*척|처럼)\s*(메일|편지|이메일)/i,
    /허위\s*사유|거짓\s*사유|날조/i
];

// ===== API =====

/**
 * 허용된 도구인지 검사합니다.
 * @param {string} toolName
 * @returns {{ valid: boolean, reason?: string }}
 */
function validateTool(toolName) {
    if (ALLOWED_TOOLS.includes(toolName)) {
        return { valid: true };
    }
    return {
        valid: false,
        reason: `'${toolName}'은(는) 사용할 수 없는 도구입니다. 허용 도구: ${ALLOWED_TOOLS.join(', ')}`
    };
}

/**
 * 수신인 이메일이 친구 목록에 있는지 검사합니다.
 * @param {string} email
 * @returns {{ valid: boolean, reason?: string }}
 */
function validateRecipient(email) {
    const cleanEmail = email.trim().toLowerCase();
    if (FRIEND_EMAILS.includes(cleanEmail)) {
        return { valid: true };
    }
    if (!cleanEmail.includes('@')) {
        return { valid: false, reason: '올바른 이메일 주소 형식이 아닙니다. (예: username@domain.com)' };
    }
    return { valid: false, reason: '등록된 친구 메일 주소만 발송 가능합니다.' };
}

/**
 * 재시도 횟수를 추적하고 제한을 검사합니다.
 * @param {string} toolName
 * @returns {{ canRetry: boolean, count: number }}
 */
function trackRetry(toolName) {
    if (!retryTracker[toolName]) {
        retryTracker[toolName] = 0;
    }
    retryTracker[toolName]++;
    const count = retryTracker[toolName];
    return {
        canRetry: count <= MAX_RETRY,
        count: count
    };
}

/**
 * 재시도 횟수를 초기화합니다.
 * @param {string} toolName
 */
function resetRetry(toolName) {
    delete retryTracker[toolName];
}

/**
 * 사용자 입력에 대한 모든 가드레일을 실행합니다.
 * @param {string} text
 * @returns {{ safe: boolean, category?: string, reason?: string, alternative?: string }}
 */
function validateInput(text) {
    if (!text || typeof text !== 'string') {
        return { safe: false, category: 'system', reason: '입력값이 유효하지 않습니다.', alternative: '올바른 메시지를 입력해주세요.' };
    }

    // 1. 탈옥·우회 검사
    for (const pat of JAILBREAK_PATTERNS) {
        if (pat.test(text)) {
            return {
                safe: false,
                category: 'jailbreak',
                reason: '안전 규칙을 우회하려는 요청은 받을 수 없습니다.',
                alternative: '규칙 안에서 안전하게 메일을 작성해드릴게요! 무엇을 도와드릴까요?'
            };
        }
    }

    // 2. 욕설·비방 검사
    for (const kw of ABUSE_KEYWORDS) {
        if (text.includes(kw)) {
            return {
                safe: false,
                category: 'abuse',
                reason: '욕설이나 비방이 포함된 요청은 수행할 수 없습니다.',
                alternative: '전달하고 싶은 내용을 예의 있게 적어볼까요? 제가 도와드릴게요!'
            };
        }
    }

    // 3. 차별·혐오 검사
    for (const pat of DISCRIMINATION_PATTERNS) {
        if (pat.test(text)) {
            return {
                safe: false,
                category: 'discrimination',
                reason: '성별·인종·문화·집단 등을 차별하는 내용은 도와드릴 수 없습니다.',
                alternative: '모두를 존중하는 표현으로 메일을 작성해보는 건 어떨까요?'
            };
        }
    }

    // 4. 거짓·기만 검사
    for (const pat of DECEPTION_PATTERNS) {
        if (pat.test(text)) {
            return {
                safe: false,
                category: 'deception',
                reason: '타인을 사칭하거나 허위 내용의 메일은 작성할 수 없습니다.',
                alternative: '본인의 신분으로 정직한 내용을 작성해볼까요?'
            };
        }
    }

    // 5. 유해 콘텐츠 검사
    for (const kw of HATE_KEYWORDS) {
        if (text.includes(kw)) {
            return {
                safe: false,
                category: 'hate',
                reason: '폭력적이거나 혐오를 유발하는 내용이 포함되어 있습니다.',
                alternative: '상대방을 배려하는 따뜻한 표현으로 바꿔볼까요?'
            };
        }
    }

    return { safe: true };
}

/**
 * 친구 메일 주소 목록을 반환합니다.
 */
function getFriendEmails() {
    return [...FRIEND_EMAILS];
}