// ========================================================================
// tools.js — 메일링 에이전트 AI 도구 정의
// ========================================================================
// 허용 도구 (3개):
//   🟢 composeMail(받는사람, 제목, 내용)  — 자유(auto)
//   🟢 showPreview(초안)                  — 자유(auto)
//   🔴 sendMail(초안)                     — 승인(ask), 사용자 확인 필수
//
// 등급 기준:
//   - 자유(auto): 외부에 영향 없는 도구 (즉시 실행)
//   - 승인(ask):  외부에 영향 있는 도구 (미리보기 + 확인 필수)
//
// 안전 규칙 (코드 강제):
//   1. sendMail 호출 전 showPreview + 사용자 승인 게이트
//   2. 동일 도구 5회 재시도 제한 (실패 시 결과 지어내지 않음)
//   3. 허용 도구 외 호출 시 거부 (guardrails.js validateTool)
// ========================================================================

// ===== 도구 실행에 필요한 UI 함수 참조 =====
// app.js에서 주입 (circular dependency 방지)
let UI = null;

function setToolUI(uiRef) {
    UI = uiRef;
}

// ===== TAO 로그 참조 =====
let tao = null;

function setTaoRef(taoRef) {
    tao = taoRef;
}

// ===== 승인 게이트 상태 =====
let _previewConfirmed = false;
let _pendingDraft = null;

function resetGate() {
    _previewConfirmed = false;
    _pendingDraft = null;
}

// ========================================================================
// 도구 1: composeMail (🟢 자유)
// ========================================================================
// 등급: 자유(auto) — 외부에 영향 없음, 즉시 실행 가능
// 설명: 받는사람, 제목, 내용을 채팅 화면에 작성하여 표시
// ========================================================================

function composeMail(recipient, subject, content) {
    // 1. 가드레일: 도구 검증
    const toolCheck = validateTool('composeMail');
    if (!toolCheck.valid) {
        if (tao) tao('composeMail', '도구 호출 검증', `거부: ${toolCheck.reason}`);
        if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 거부</span><p>${toolCheck.reason}</p>`);
        return { success: false, error: toolCheck.reason };
    }

    // 2. 수신인 검증 (이메일 형식이면)
    if (recipient && recipient.includes('@')) {
        const recCheck = validateRecipient(recipient);
        if (!recCheck.valid) {
            if (tao) tao('composeMail', '수신인 검증', `거부: ${recCheck.reason}`);
            if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 거부</span><p>${recCheck.reason}</p>`);
            return { success: false, error: recCheck.reason };
        }
    }

    // 3. TAO 로그
    if (tao) {
        tao('composeMail', `메일 작성: 받는사람=${recipient}, 제목=${subject}`, '메일 내용 작성 완료');
    }

    // 4. 실행
    const draft = {
        to: recipient,
        subject: subject,
        body: content,
        createdAt: new Date().toISOString()
    };

    _pendingDraft = draft;

    // 5. UI 표시
    if (UI) {
        UI.addAgentMessage(`
            <span class="tool-badge compose">🟢 composeMail</span>
            <p><strong>📧 메일을 작성했습니다.</strong></p>
            <div class="email-preview">
                <div class="preview-label">📄 작성 내용</div>
                <div class="preview-row"><span class="label">받는사람</span><span class="value">${UI.escapeHtml(recipient)}</span></div>
                <div class="preview-row"><span class="label">제목</span><span class="value">${UI.escapeHtml(subject)}</span></div>
                <div class="preview-body">${UI.escapeHtml(content)}</div>
            </div>
        `);
    }

    return { success: true, draft: draft };
}

// ========================================================================
// 도구 2: showPreview (🟢 자유)
// ========================================================================
// 등급: 자유(auto) — 외부에 영향 없음, 즉시 실행 가능
// 설명: 발송 전 받는사람·제목·내용을 카드로 미리보기
//        사용자가 '확인' 버튼을 눌러야 sendMail 게이트 열림
// ========================================================================

function showPreview(draft) {
    // 1. 가드레일: 도구 검증
    const toolCheck = validateTool('showPreview');
    if (!toolCheck.valid) {
        if (tao) tao('showPreview', '도구 호출 검증', `거부: ${toolCheck.reason}`);
        if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 거부</span><p>${toolCheck.reason}</p>`);
        return { success: false, error: toolCheck.reason };
    }

    if (!draft) {
        if (tao) tao('showPreview', '초안 없음', '먼저 composeMail로 메일을 작성해주세요.');
        if (UI) UI.addAgentMessage(`<span class="tool-badge system">⚠️ 오류</span><p>미리보기를 표시할 메일 초안이 없습니다. 먼저 메일을 작성해주세요.</p>`);
        return { success: false, error: '초안 없음' };
    }

    // 2. TAO 로그
    if (tao) {
        tao('showPreview', `미리보기 제공: 받는사람=${draft.to}, 제목=${draft.subject}`, '미리보기 카드 표시 완료');
    }

    // 3. 미리보기 카드 + 확인/취소 버튼 표시
    if (UI) {
        UI.addAgentMessage(`
            <span class="tool-badge compose">🟢 showPreview</span>
            <p><strong>📋 메일 미리보기</strong></p>
            <div class="email-preview preview-card">
                <div class="preview-row"><span class="label">받는사람</span><span class="value">${UI.escapeHtml(draft.to)}</span></div>
                <div class="preview-row"><span class="label">제목</span><span class="value">${UI.escapeHtml(draft.subject)}</span></div>
                <div class="preview-body">${UI.escapeHtml(draft.body)}</div>
            </div>
            <p style="margin-top:6px;font-size:13px;color:#6b7280;">위 내용으로 발송하시겠습니까?</p>
            <div class="confirm-send">
                <button class="btn-confirm" onclick="MailAgent.confirmPreview()">✅ 확인</button>
                <button class="btn-cancel-send" onclick="MailAgent.cancelPreview()">❌ 취소</button>
            </div>
        `);
    }

    _pendingDraft = draft;
    _previewConfirmed = false;

    return { success: true, draft: draft, waitingForConfirm: true };
}

// ========================================================================
// 도구 3: sendMail (🔴 승인)
// ========================================================================
// 등급: 승인(ask) — 외부에 영향 있음, 미리보기 + 확인 필수
// 제약:
//   - showPreview()로 미리보기 후 사용자가 '확인' 버튼을 눌러야 실행 가능
//   - 등록된 친구 메일 주소만 발송 가능
//   - 발송(write)만 가능, 읽기·삭제 불가
//   - 실패 시 결과를 절대 지어내지 않음
// ========================================================================

function sendMail() {
    // 1. 가드레일: 도구 검증
    const toolCheck = validateTool('sendMail');
    if (!toolCheck.valid) {
        if (tao) tao('sendMail', '도구 호출 검증', `거부: ${toolCheck.reason}`);
        if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 거부</span><p>${toolCheck.reason}</p>`);
        return { success: false, error: toolCheck.reason };
    }

    // 2. 게이트 검사: showPreview + 확인 필수
    if (!_previewConfirmed) {
        const msg = '발송 전 미리보기에서 먼저 "확인" 버튼을 눌러주세요.';
        if (tao) tao('sendMail', '게이트 검사', `거부: ${msg}`);
        if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 게이트 차단</span><p>${msg}</p>`);
        return { success: false, error: msg };
    }

    // 3. 초안 확인
    if (!_pendingDraft) {
        const msg = '발송할 메일 초안이 없습니다. 먼저 composeMail로 메일을 작성해주세요.';
        if (tao) tao('sendMail', '초안 없음', `거부: ${msg}`);
        if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 오류</span><p>${msg}</p>`);
        return { success: false, error: msg };
    }

    // 4. 수신인 검증 (화이트리스트)
    const recipient = _pendingDraft.to;
    if (recipient && recipient.includes('@')) {
        const recCheck = validateRecipient(recipient);
        if (!recCheck.valid) {
            if (tao) tao('sendMail', '수신인 검증', `거부: ${recCheck.reason}`);
            if (UI) UI.addAgentMessage(`<span class="tool-badge system">🚫 거부</span><p>${recCheck.reason}</p>`);
            _previewConfirmed = false;
            return { success: false, error: recCheck.reason };
        }
    }

    // 5. 읽기/삭제 동작 차단 (sendMail은 발송(write) 전용)
    // tools.js에서 sendMail은 오직 발송만 수행하도록 설계됨
    // → 이 파일의 sendMail 함수 자체가 write 전용이므로 추가 검증 불필요

    // 6. 재시도 제한 검사
    const retry = trackRetry('sendMail');
    if (!retry.canRetry) {
        // 5회 초과 → 결과 지어내지 않고 실패 보고
        const msg = `sendMail이 ${MAX_RETRY}회 시도에도 실행되지 않았습니다. 오류가 지속됩니다.`;
        if (tao) tao('sendMail', '재시도 초과', `실패: ${msg}`);
        if (UI) {
            UI.addAgentMessage(`
                <span class="tool-badge system">⚠️ 실패</span>
                <p>${msg}</p>
                <p style="font-size:13px;color:#6b7280;margin-top:4px;">다시 시도하시겠습니까?</p>
                <div class="confirm-send">
                    <button class="btn-confirm" onclick="MailAgent.retrySend()">🔄 다시 시도</button>
                    <button class="btn-cancel-send" onclick="MailAgent.cancelSend()">❌ 취소</button>
                </div>
            `);
        }
        return { success: false, error: msg, retryExhausted: true };
    }

    // 7. Mock 발송 실행
    const mockResult = {
        status: 'success',
        message: '메일이 성공적으로 발송되었습니다.',
        to: _pendingDraft.to,
        subject: _pendingDraft.subject,
        sentAt: new Date().toLocaleString('ko-KR'),
        messageId: `MAIL-${Date.now().toString(36).toUpperCase()}`
    };

    // 8. TAO 로그
    if (tao) {
        tao('sendMail', `사용자 승인 완료, Mock 발송 실행`, `발송 완료. ID: ${mockResult.messageId}`);
    }

    // 9. 게이트 초기화
    resetGate();
    resetRetry('sendMail');

    // 10. UI 결과 표시
    if (UI) {
        UI.addAgentMessage(`
            <span class="tool-badge send">🔴 sendMail (승인)</span>
            <div class="send-result">
                <div class="result-icon">✅</div>
                <div class="result-text">${mockResult.message}</div>
                <div class="result-detail">
                    📎 발송 ID: ${mockResult.messageId}<br>
                    📧 받는사람: ${UI.escapeHtml(mockResult.to)}<br>
                    📧 제목: ${UI.escapeHtml(mockResult.subject)}<br>
                    🕐 발송 시간: ${mockResult.sentAt}
                </div>
            </div>
            <p style="margin-top:8px;font-size:13px;color:#6b7280;">💡 다른 메일 작성이 필요하시면 말씀해주세요!</p>
        `);
        UI.addSystemMessage('🔔 sendMail은 Mock으로 동작합니다. 실제 메일이 발송되지는 않았습니다.');
    }

    return { success: true, result: mockResult };
}

// ===== MailAgent 전역 객체 (HTML onclick 연결) =====
window.MailAgent = {
    // showPreview → 확인 버튼
    confirmPreview: function() {
        _previewConfirmed = true;
        if (UI) {
            UI.addAgentMessage(`<span class="tool-badge system">✅ 확인 완료</span><p>미리보기를 확인했습니다. 이제 메일을 발송합니다...</p>`);
        }
        // 즉시 sendMail 실행
        sendMail();
    },
    // showPreview → 취소 버튼
    cancelPreview: function() {
        _previewConfirmed = false;
        resetGate();
        if (tao) tao('sendMail', '사용자 취소', '미리보기에서 사용자가 취소하였습니다.');
        if (UI) {
            UI.addAgentMessage(`<p>메일 발송이 취소되었습니다.</p><p style="margin-top:4px;font-size:13px;color:#6b7280;">다른 요청이 있으시면 말씀해주세요.</p>`);
        }
    },
    // sendMail 재시도
    retrySend: function() {
        resetRetry('sendMail');
        sendMail();
    },
    // sendMail 취소
    cancelSend: function() {
        resetGate();
        resetRetry('sendMail');
        if (tao) tao('sendMail', '사용자 취소', '사용자가 발송을 취소하였습니다.');
        if (UI) {
            UI.addAgentMessage(`<p>메일 발송이 취소되었습니다.</p><p style="margin-top:4px;font-size:13px;color:#6b7280;">다른 요청이 있으시면 말씀해주세요.</p>`);
        }
    }
};