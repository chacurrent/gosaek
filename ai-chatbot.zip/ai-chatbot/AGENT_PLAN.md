# AGENT_PLAN.md — 메일링 에이전트 AI 5요소 정의

> 이 문서는 메일링 에이전트 AI의 5요소(목표, 계획, 상태, 도구, 결과)와 TAO 사이클을 정의합니다.

---

## 🎯 목표 (Goal)

**사용자의 요청을 바탕으로 메일을 작성하고, Mock 발송 결과를 보여준다.**

- 사용자가 자연어로 메일 작성을 요청하면 에이전트가 필요한 정보를 수집
- 수집된 정보를 바탕으로 메일 초안 작성
- 사용자 승인 후 Mock 발송 결과 표시

---

## 📋 계획 (Plan)

에이전트는 **4단계 파이프라인**으로 동작합니다.

```
Phase 1 [정보 수집]
  사용자 요청 분석 → 부족한 정보 식별 → askUser로 질문
  ↓
Phase 2 [초안 작성]
  모든 정보 수집 완료 → composeMail() 실행 → showPreview() 실행
  ↓
Phase 3 [발송 승인]
  미리보기 카드 표시 → 사용자 '확인' 버튼 대기
  ↓
Phase 4 [발송 완료]
  sendMail() 실행 → Mock 발송 결과 표시
```

### Phase 상세

| Phase | 설명 | 도구 | 등급 |
|-------|------|------|------|
| **collecting** | 사용자 요청 분석, 부족한 정보 askUser로 질문 | `askUser` (내부) | 🟢 자유 |
| **composing** | composeMail로 메일 작성 + showPreview로 미리보기 | `composeMail`, `showPreview` | 🟢 자유 |
| **confirming** | 사용자 승인 대기 (확인/취소 버튼) | `sendMail` (대기) | 🔴 승인 |
| **done** | Mock 발송 완료, 다음 요청 대기 | - | - |

---

## 💾 상태 (State)

에이전트는 다음 정보를 상태(`agentState`)로 관리합니다.

```javascript
const agentState = {
    userRequest:           '',        // 사용자 요청 원문
    recipient:             '',        // 받는 사람 (이메일 주소)
    subject:               '',        // 메일 제목
    keyContent:            '',        // 본문 핵심 내용
    missingInfo:           [],        // 부족한 정보 목록
    emailDraft:            null,      // 생성된 메일 초안
    sendResult:            null,      // Mock 발송 결과
    taoLog:                [],        // TAO 실행 기록 배열
    phase:                 'idle',    // idle | collecting | composing | confirming | done
    waitingForInput:       false,     // 사용자 입력 대기 중 여부
    pendingSendApproval:   false,     // sendMail 승인 대기 중 여부
    stopRequested:         false      // 비상 정지 플래그
};
```

---

## 🛠 도구 (Tools)

### 허용 도구 (3개)

| 도구 | 등급 | 시그니처 | 설명 |
|------|------|---------|------|
| `composeMail` | 🟢 **자유(auto)** | `(recipient, subject, content)` | 메일 내용을 채팅에 작성하여 표시 |
| `showPreview` | 🟢 **자유(auto)** | `(draft)` | 받는사람·제목·내용을 카드로 미리보기 + 확인/취소 버튼 |
| `sendMail` | 🔴 **승인(ask)** | `()` | Mock 메일 발송 (showPreview 확인 필수) |

### 등급 분류 기준

| 등급 | 기준 | 예시 |
|------|------|------|
| 🟢 **자유(auto)** | 외부에 영향이 없는 도구 → 즉시 실행 | `composeMail`, `showPreview` |
| 🔴 **승인(ask)** | 외부에 영향이 있는 도구 → 미리보기 + 확인 필수 | `sendMail` |

### 제약사항

| 도구 | 제약 |
|------|------|
| `composeMail` | 수신인 이메일 주소일 경우 화이트리스트 검사 |
| `showPreview` | 초안(draft) 필수, 없으면 오류 |
| `sendMail` | 🔐 **게이트**: `showPreview` 확인 버튼 필수<br>👥 **수신인**: 친구 메일만 허용<br>📤 **동작**: 발송(write) 전용, 읽기/삭제 불가<br>🔄 **재시도**: 최대 5회, 초과 시 실패 보고 |

### 거부 대상

| 유형 | 설명 |
|------|------|
| 허용 외 도구 | `composeMail`, `showPreview`, `sendMail` 외 모든 도구 호출 |
| 외부 수신인 | 친구 메일 3개 외 모든 주소 |
| sendMail 읽기/삭제 | sendMail은 발송(write)만 가능, 읽기·삭제 요청 시 거부 |
| 4가지 유형 요청 | 욕설·비방, 차별·혐오, 거짓·기만, 탈옥·우회 |

---

## 📊 결과 (Result)

### 성공 케이스

```javascript
{
    success: true,
    result: {
        status: 'success',
        message: '메일이 성공적으로 발송되었습니다.',
        to: 'sunny.icmhs@gmail.com',
        subject: '프로젝트 회의 일정',
        sentAt: '2026. 6. 16. 오후 5:30:00',
        messageId: 'MAIL-ABC123'
    }
}
```

### 실패 케이스

```javascript
{
    success: false,
    error: '등록된 친구 메일 주소만 발송 가능합니다.'
}
```

### 사용자 피드백 유형

| 상황 | 피드백 |
|------|--------|
| 성공 | ✅ 메일 발송 완료 + 상세 정보 카드 |
| 거부 | 🚫 ①거부사실 ②사유(1줄) ③건전한 대안 |
| 실패 | ⚠️ 실제 오류 내용 그대로 보고 + 재시도/취소 선택 |
| 중지 | 🛑 모든 작업 중단 + 입력 대기 |

---

## 🔄 TAO 사이클 (Thought-Action-Observation)

매 턴 에이전트는 **TAO (추론-행동-관찰)** 방식으로 사고하며, 모든 기록은 TAO 패널에 표시됩니다.

### TAO 구성

| 요소 | 설명 | 예시 |
|------|------|------|
| **T**hought | 현재 상태를 보고 다음 행동을 판단한 이유 | `요청 분석 결과 부족한 정보 감지: 받는 사람` |
| **A**ction | 실행한 도구 | `🟢 composeMail` |
| **O**bservation | 도구 실행 결과 | `메일 내용 작성 완료` |

### TAO 로깅 대상 (모든 행동)

- ✅ `composeMail()` 성공/실패
- ✅ `showPreview()` 성공
- ✅ `sendMail()` 승인 대기 / 승인 완료 / 거절됨
- ✅ **도구 거부** (허용 목록 외 호출 시도)
- ✅ **수신인 거부** (친구 목록 외 주소)
- ✅ **4가지 유형 거부** (욕설/차별/거짓/탈옥)
- ✅ **비상 정지** (stop 버튼)
- ✅ **시스템 메시지** (사용자 입력 수신 등)

### TAO 패널 UI

```
┌────────────────────────────────┐
│ 📋 TAO 실행 기록          [3]  │ (접이식 헤더)
├────────────────────────────────┤
│ #1 🟢 composeMail              │
│ T: 메일 작성: 받는사람=sunny...│
│ A: 🟢 composeMail              │
│ O: 메일 내용 작성 완료         │
├────────────────────────────────┤
│ #2 🟢 showPreview              │
│ T: 미리보기 제공...            │
│ A: 🟢 showPreview              │
│ O: 미리보기 카드 표시 완료     │
├────────────────────────────────┤
│ #3 🔴 sendMail                 │
│ T: 사용자 승인 완료...         │
│ A: 🔴 sendMail                 │
│ O: 발송 완료. ID: MAIL-...     │
└────────────────────────────────┘
```

---

## 📂 파일 구조

```
ai-chatbot/
├── index.html           # HTML (guardrails.js → tools.js → app.js 순 로드)
├── style.css            # 전체 스타일시트
├── guardrails.js        # 가드레일 모듈 (도구제한, 수신인검증, 4유형거부, 재시도, 개인정보)
├── tools.js             # 도구 정의 (composeMail / showPreview / sendMail)
├── app.js               # 메인 애플리케이션 (UI + TAO + 추론엔진 + 중지버튼)
├── SAFETY_POLICY.md     # 안전 정책 문서
└── AGENT_PLAN.md        # 5요소 정의 문서 (현재 파일)
```

### 로드 순서

```
guardrails.js  →  tools.js  →  app.js
 (가드레일)       (도구 정의)    (UI + TAO + 추론)
```

### 의존성

- `guardrails.js`: 독립적 (전역 함수 제공)
- `tools.js`: `guardrails.js` 함수 사용 + `app.js`의 UI/TAO 참조 주입 필요
- `app.js`: `guardrails.js` + `tools.js` 함수 사용, `setToolUI()`, `setTaoRef()`로 참조 제공